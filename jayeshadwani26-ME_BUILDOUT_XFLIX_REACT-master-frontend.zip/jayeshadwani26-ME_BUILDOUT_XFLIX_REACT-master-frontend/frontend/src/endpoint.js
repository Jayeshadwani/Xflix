const mockurl = "https://45ed4196-fd22-45a2-a8b7-2c1ce0985b59.mock.pstmn.io"

export default mockurl;